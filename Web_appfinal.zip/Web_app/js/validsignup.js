			//Validation Code For Inputs
var email = document.forms['formsignup']['email'];;
var password = document.forms['formsignup']['password'];
var psw-repeat = document.getElementById('psw-repeat');
var eid_error = document.getElementById('eid_error');
var pwd_error = document.getElementById('pwd_error');

email.addEventListener('textInput', email_Verify);
password.addEventListener('textInput', password_Verify);
function validated() {
	if (email.value.length < 9) {
		email.style.border = "1px solid red";
		eid_error.style.display = "block";
		email.focus();
		return false;
	}
	if (password.value.length < 6) {
		password.style.border = "1px solid red";
		pwd_error.style.display = "block";
		password.focus();
		return false;
	}

	
}
function email_Verify(){
	if (email.value.length >= 8) {
		email.style.border = "1px solid silver";
		eid_error.style.display = "none";
		return true;
	}
	if (password.value.length >= 5) {
		password.style.border = "1px solid silver";
		pwd_error.style.display = "none";
		return true;
	}
}
